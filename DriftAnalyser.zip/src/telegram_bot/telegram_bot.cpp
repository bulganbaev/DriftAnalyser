#include <WiFi.h>
#include <WiFiManager.h>  // Include WiFiManager library
#include <UniversalTelegramBot.h>
#include "config/config.h"
#include "gps_controller/gps_controller.h"
#include "telegram_bot.h"
#include <ArduinoJson.h>

WiFiClient client;
UniversalTelegramBot bot(BOT_TOKEN, client);
const int botRequestDelay = 1000;
unsigned long lastTimeBotRan;

void initializeTelegramBot() {
    lastTimeBotRan = 0;
}

// Function to handle "get gps" command
void handleGPSCommand(String chat_id) {
    readGPSData();

    // Get GPS data
    double latitude = getLatitude();
    double longitude = getLongitude();
    double speed = getSpeed();
    double altitude = getAltitude();
    
    // Create a message with the GPS data
    String message = "GPS Data:\n";
    message += "Latitude: " + String(latitude, 6) + "\n";
    message += "Longitude: " + String(longitude, 6) + "\n";
    message += "Speed: " + String(speed) + " km/h\n";
    message += "Altitude: " + String(altitude) + " m\n";

    // Send the message to the Telegram chat
    bot.sendMessage(chat_id, message, "");
}

// Function to check for Telegram messages
void checkTelegramMessages() {
    if (millis() - lastTimeBotRan > botRequestDelay) {
        int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
        for (int i = 0; i < numNewMessages; i++) {
            String chat_id = bot.messages[i].chat_id;
            String text = bot.messages[i].text;

            Serial.println("Message received: " + text);

            if (text == "/getgps") {
                handleGPSCommand(chat_id);
            } else {
                bot.sendMessage(chat_id, "Unknown command! Try /getgps", "");
            }
        }
        lastTimeBotRan = millis();
    }
}
