#ifndef TELEGRAM_BOT_H
#define TELEGRAM_BOT_H

void initializeTelegramBot();
void checkTelegramMessages();

#endif
